
import java.util.ArrayList;


public class QuestionLists {
    private ArrayList<QandA> questionlist;
    
    public QuestionLists(){
        
        
    }
}
