
public class App {


    public static void main(String[] args) {
        QandA q1 = new QandA("What does ROM stand for?", "Read only memory");
        
        if(q1.isAnswerCorrect("Read only")){
            System.out.println("It works!");
            
        }
        
    }
    
}
