
public class App {


    public static void main(String[] args) {
        QandA q1 = new QandA("What does ROM stand for?", "Read only memory");
        q1.isAnswerCorrect("Read only");
        Player newPlayer1 = new Player("playerName", "1st", 0);
        newPlayer1.CreatePlayer();//creates a player
        Player newPlayer2 = new Player("playerName", "2nd", 20);
        newPlayer2.CreatePlayer();//creates another player
        newPlayer1.NewPosition(newPlayer2);//sets players in order based upon score 
        
    }
    
}
