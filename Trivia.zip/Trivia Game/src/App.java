
import java.util.Scanner;


public class App {


    public static void main(String[] args) {

    
        Controller triviaGame = new Controller();
    
        
    }
    
}
